class SeedStock

  attr_accessor :grams_remaining, :seed_stock, :mutant_gene_id, :gene_information, :last_planted, :storage

  def initialize(seed_stock, mutant_gene_id, last_planted, storage, grams_remaining)
    @seed_stock, @mutant_gene_id, @last_planted, @storage, @grams_remaining = seed_stock, mutant_gene_id, last_planted, storage, grams_remaining
  end

  def planting7
    return if check_less_0
    self.grams_remaining -= 7
  end

  def check_less_0
    if self.grams_remaining - 7 < 0
      p "WARNING: we have run out of Seed Stock #{self.seed_stock}"
      true
    elsif self.grams_remaining - 7 == 0
      p "WARNING: we have run out of Seed Stock #{self.seed_stock}"
      false
    else
      false       
    end
  end

  def link_gene_information(gene_informations)
    self.gene_information = gene_informations.find { |i| i.gene_id == self.mutant_gene_id }
  end

  def format_line
    seed_stock + ' ' + mutant_gene_id + ' ' + last_planted + ' ' + storage + ' ' + grams_remaining.to_s
  end  
end

class GeneInformation

  attr_accessor :seed_stock, :gene_name, :gene_id

  def initialize(gene_id, gene_name, mutant_phenotype)
    @gene_id, @gene_name, @mutant_phenotype = gene_id, gene_name, mutant_phenotype
  end

end

class CrossData

  attr_accessor :parent1, :parent2, :f2_wild, :f2_p1, :f2_p2, :f2_p1p2

  def initialize(parent1, parent2, f2_wild, f2_p1, f2_p2, f2_p1p2)
    @parent1, @parent2, @f2_wild, @f2_p1, @f2_p2, @f2_p1p2 = parent1, parent2, f2_wild, f2_p1, f2_p2, f2_p1p2
  end

  def link_seed_stock(seed_stocks)
    self.parent1 = seed_stocks.find { |i| i.seed_stock == self.parent1 }
    self.parent2 = seed_stocks.find { |i| i.seed_stock == self.parent2 }
  end

  def chi_square
    total_seeds = f2_wild + f2_p1 + f2_p2 + f2_p1p2
    f2_wild_esperated = total_seeds * 9 / 16
    f2_p1_esperated = total_seeds * 3 / 16
    f2_p2_esperated = total_seeds * 3 /16
    f2_p1p2_esperated = total_seeds * 1 / 16
    result = ((f2_wild - f2_wild_esperated ) ** 2 / f2_wild_esperated) + ((f2_p1 - f2_p1_esperated) ** 2 / f2_p1_esperated) + ((f2_p2 - f2_p2_esperated) ** 2 / f2_p2_esperated) + ((f2_p1p2 - f2_p1p2_esperated) ** 2 / f2_p1p2_esperated)
    result
  end

end

gene_informations = []

# File.open ('gene_information.tsv') do |f|
File.open (ARGV[0]) do |f|
  f.each_line do |line|
    next if f.lineno == 1
    data = line.split' '
    gene_information = GeneInformation.new(data[0], data[1], data[2, data.size].join(' '))
    gene_informations.push(gene_information)
  end 
end

seed_stocks = []

# File.open ('seed_stock_data.tsv') do |f|
File.open (ARGV[1]) do |f|
  f.each_line do |line|
    next if f.lineno == 1
    data = line.split' '
    seed_stock = SeedStock.new(data[0], data[1], data[2], data[3], data[4].to_i)
    seed_stock.planting7
    seed_stock.link_gene_information(gene_informations)
    seed_stocks.push(seed_stock)
  end 
end


cross_datas = []

# File.open ('cross_data.tsv') do |f|
File.open (ARGV[2]) do |f|
  f.each_line do |line|
    next if f.lineno == 1
    data = line.split' '
    cross_data = CrossData.new(data[0], data[1], data[2].to_f, data[3].to_f, data[4].to_f, data[5].to_f)
    cross_data.link_seed_stock(seed_stocks)
    cross_datas.push(cross_data)
  end 
end

cross_datas.each do |cross_data|
  if cross_data.chi_square > 7.82
    parent1 = cross_data.parent1
    parent2 = cross_data.parent2
    p "Recording: #{parent1.gene_information.gene_name} is genetically linked to #{parent2.gene_information.gene_name} with chisquare score #{cross_data.chi_square}"
    puts
    p 'Final Report:'
    p "#{parent1.gene_information.gene_name} is linked to #{parent2.gene_information.gene_name}"
    p "#{parent2.gene_information.gene_name} is linked to #{parent1.gene_information.gene_name}"
  end  
end  

new_stock_file = File.new("new_stock_file.tsv", "w")

new_stock_file.puts("Seed_Stock Mutant_Gene_ID  Last_Planted  Storage Grams_Remaining")

seed_stocks.each do |seed_stock|
  new_stock_file.puts(seed_stock.format_line)
end

new_stock_file.close  


